package com.example.rigoeffector.traveapp;

/**
 * Created by rigoeffector on 12/8/20.
 */

public class Constants {

    public  static  final String URL_BASE = "http://192.168.43.234/Travel/";
}
